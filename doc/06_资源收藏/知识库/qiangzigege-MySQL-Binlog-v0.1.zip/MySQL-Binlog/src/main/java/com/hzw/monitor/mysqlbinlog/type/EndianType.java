package com.hzw.monitor.mysqlbinlog.type;
/**
 * 
 * @author zhiqiang.liu
 * @2016年1月1日
 *
 */
public enum EndianType {
	BigEndian, LittleEndian
}
